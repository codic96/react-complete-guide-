import { useEffect } from 'react';

export default function App() {
  useEffect(() => {
    console.log('Component Mounted');
  }, []);

  return <h1>useEffect Example</h1>;
}
