function User(props) {
  return <h2>{props.name}</h2>;
}

export default function App() {
  return <User name='React Developer' />;
}
