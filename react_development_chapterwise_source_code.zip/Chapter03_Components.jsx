function Greeting() {
  return <p>Reusable Component</p>;
}

export default function App() {
  return <Greeting />;
}
