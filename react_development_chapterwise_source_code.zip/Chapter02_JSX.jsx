export default function App() {
  const name = 'Vipin';
  return <h1>Welcome, {name}</h1>;
}
